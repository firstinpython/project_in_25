from django.urls import path
from .views import form

app_name = "feedackposts"
urlpatterns = [
    path('', form, name="label")
]
