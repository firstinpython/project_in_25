from django.shortcuts import render
from .models import BidForms
from django.conf import settings
# Create your views here.
from .forms import FeedbackForms
from django.core.mail import send_mail
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


def form(request):
    if request.method == 'POST':
        form = FeedbackForms(request.POST)
        if form.is_valid():
            BidForms(username=request.POST['username'],email = request.POST['email']).save()
            send_messages(request.POST['email'], request.POST['username'])
            form = FeedbackForms()
            return render(request, 'feedbackposts/index.html', context={"form": form})
    else:
        form = FeedbackForms()
        return render(request,'feedbackposts/index.html', context={"form":form})

def send_messages(email,username):
    msg = MIMEMultipart()
    to_email = str(email)
    message = f'Здравствуйте {username}. Вы обратились в компанию it-managment вы очень благодарны Вам. Но к сожалению сообщаем что наш сайт пока что на доработке'
    msg.attach(MIMEText(message,'plain'))
    server = smtplib.SMTP('smtp.mail.ru: 25')
    server.starttls()
    server.login('ntr.0707@mail.ru', 'cfaBsgv14rw8i5fZApcq')
    server.sendmail('ntr.0707@mail.ru',str(email),msg.as_string())
    server.quit()