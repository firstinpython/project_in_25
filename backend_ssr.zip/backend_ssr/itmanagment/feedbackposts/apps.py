from django.apps import AppConfig


class FeedbackpostsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'feedbackposts'
