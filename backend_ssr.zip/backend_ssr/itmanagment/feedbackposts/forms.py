from django import forms
from .models import BidForms
class FeedbackForms(forms.Form):

    username = forms.CharField(widget=forms.TextInput(attrs={
        'class':'feedback-form__input bottom-input',
        'placeholder':'input email'
    }))
    email = forms.EmailField(widget=forms.TextInput(attrs={
        'class':'feedback-form__input',
        'placeholder':'+7 (495) 792-66-69'
    }))
    class Meta:
        model = BidForms
        fields = ('username','email')