from django.db import models
from django.contrib.auth.models import AbstractUser


# Create your models here.

class Company(models.Model):
    name = models.CharField(max_length=120)
    image = models.ImageField(upload_to="company_image",null=True,blank=True)

class UserFeedback(models.Model):
    first_name = models.CharField(max_length=120, verbose_name="firstname")
    email = models.EmailField(max_length=100, verbose_name='email')

class User(AbstractUser):
    image = models.ImageField(upload_to="users_images", null=True, blank=True)
    status = models.TextField(verbose_name='status')
    company = models.TextField(verbose_name='company',null=True, blank=True)



