from django.shortcuts import render,HttpResponseRedirect,reverse
from django.contrib import auth
from .models import User,Company
from .forms import UserLoginForm, UserSign



# Create your views here.

def my_login(request):
    if request.method == 'POST':
        forms = UserLoginForm(request.POST)
        username = request.POST['username']
        password = request.POST['password']
        user = auth.authenticate(username = username, password= password)
        if user:
            print('ok')
            auth.login(request,user)
            return HttpResponseRedirect(reverse('feedackposts:label'))


    context = {
            'form':UserLoginForm()
        }
    return render(request, 'users/login.html', context=context)


def register(request):
    if request.method == "POST":
        form = UserSign(data=request.POST)
        if form.is_valid():
            form.save()
            return render(request, 'users/registration.html')
    form = UserSign()
    context = {'form':form}
    return render(request,'users/registration.html',context=context)


def profile(request):
    if request.user.is_active:
        return render(request,'users/profile.html')
    return HttpResponseRedirect(reverse("users:register"))
def employees(request):
    if request.user.is_active:
        return render(request,'users/employees.html')



