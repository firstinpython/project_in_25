from django.urls import path,include
from .views import my_login, register,profile,employees
app_name = "users"
urlpatterns = [

    path('login/', my_login,name='login'),
    path('register/',register,name='register'),
    path('profile/',profile, name = "profile"),
    path('employees/', employees,name="emaployees")
]