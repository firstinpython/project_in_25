from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django import forms
from .models import UserFeedback, User,Company



class UserLoginForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={
        'class':'registr-block__first-name',
    }))
    password = forms.CharField(widget=forms.PasswordInput(attrs={
        'class':'registr-block__last-name',
    }))

    class Meta:
        model = UserFeedback
        fields = ('username', 'password')


class UserSign(UserCreationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'registr-block__name',
        'placeholder':'username'
    }))
    password1 = forms.CharField(widget=forms.PasswordInput(attrs={
        'class': 'registr-block__name',
        'placeholder': 'password'
    }))
    first_name = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'registr-block__name',
        'placeholder': 'first_name'
    }))
    last_name = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'registr-block__name',
        'placeholder': 'last_name'
    }))
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={
        'class': 'registr-block__name',
        'placeholder': 'password'
    }))
    email = forms.EmailField(widget=forms.EmailInput(attrs={
        'class': 'registr-block__name',
        'placeholder': 'email'
    }))
    company = forms.CharField()
    status = forms.CharField()

    class Meta:
        model = User
        fields = ('username','password1', 'first_name', 'last_name', 'password2', 'email', 'company', 'status')


