from django.urls import path,include
from .views import main_page

app_name = "supervisor"
urlpatterns = [
    path('',main_page,name='main-page')
]