from django.shortcuts import render,HttpResponseRedirect,reverse

# Create your views here.

def main_page(request):
    if request.user.is_active:
        return render(request, 'supervisor/main-page.html')
    else:
        return HttpResponseRedirect(reverse('users:login'))