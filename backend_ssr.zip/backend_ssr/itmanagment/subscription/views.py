from django.shortcuts import render,HttpResponseRedirect, reverse

# Create your views here.

def subscription(request):
    if request.user.is_active:
        return render(request,'subscription/subscription.html')
    else:
        HttpResponseRedirect(reverse('users:login'))
