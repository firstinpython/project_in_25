from django.shortcuts import render,reverse,HttpResponseRedirect

# Create your views here.

def projects(request):
    if request.user.is_active:
        return render(request,'projects/projects.html')
    else:
        HttpResponseRedirect(reverse('users:login'))

def project(request):
    if request.user.is_active:
        return render(request, 'projects/project.html')
    else:
        HttpResponseRedirect(reverse('users:login'))