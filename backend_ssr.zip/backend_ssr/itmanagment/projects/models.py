from django.db import models

# Create your models here.

class Tasks(models.Model):
    name = models.CharField(verbose_name='title',max_length=120)
    description = models.CharField(verbose_name='description', max_length=300)

class Projects(models.Model):
    name = models.CharField(verbose_name='title',max_length=120)
    description = models.CharField(verbose_name = 'description', max_length=300)
    created_data = models.DateTimeField(auto_now_add=True)
    updated_data = models.DateTimeField(auto_now=True)
    tasks = models.ForeignKey(to=Tasks, on_delete=models.CASCADE, verbose_name="tasks")
