from django.urls import path
from .views import projects,project
app_name = 'projects'
urlpatterns = [
    path('', projects, name='projects'),
    path('project/',project,name='project')

]